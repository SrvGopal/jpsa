import Link from "next/link";

export default function Page() {
  return (
    <div className="container page">
      <div className="eyebrow">EDITORIAL OFFICE</div>
      <h1>Contact</h1>
      <div className="prose"><p>Editorial enquiries: <strong>editor@jpsa-journal.org.in</strong></p><p>Add the verified postal address and official contact details before launch.</p></div>
    </div>
  );
}
