import Link from "next/link";

export default function Page() {
  return (
    <div className="container page">
      <div className="eyebrow">ABOUT THE JOURNAL</div>
      <h1>About JPSA</h1>
      <div className="prose"><p>Journal of Physical Sciences Advances is being developed as a peer-reviewed scholarly journal covering research across physics and related physical sciences.</p><h2>Journal information</h2><p>Official bibliographic and publisher information will be displayed here once established.</p></div>
    </div>
  );
}
