
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Editorial Board | JPSA",
  description:
    "Meet the editorial leadership and academic contributors of the Journal of Physical Sciences Advances.",
};

export default function EditorialBoardPage() {
  return (
    <main className="container page">
      <div className="eyebrow">JOURNAL GOVERNANCE</div>

      <h1>Editorial Board</h1>

      <p className="lead">
        The editorial board is responsible for maintaining the academic
        standards, editorial integrity and scholarly direction of the
        Journal of Physical Sciences Advances.
      </p>

      <section className="prose">
        <h2>Editorial leadership</h2>

        <p>
          Editorial appointments and institutional affiliations will be
          published here after formal confirmation by the journal.
        </p>

        <div className="notice">
          <strong>Editorial information pending verification.</strong>
          <p>
            The editorial board directory is being finalized. Verified
            names, designations, institutional affiliations, research
            interests and professional identifiers will be added before
            publication.
          </p>
        </div>

        <h2>Editorial responsibilities</h2>

        <p>
          The editorial team is expected to oversee the following
          responsibilities:
        </p>

        <ul>
          <li>
            Assess whether submitted manuscripts fall within the
            journal&apos;s aims and scope.
          </li>
          <li>
            Coordinate independent peer review and evaluate reviewer
            recommendations.
          </li>
          <li>
            Make editorial decisions based on scholarly merit and
            applicable publication policies.
          </li>
          <li>
            Manage revisions, corrections and publication-related
            concerns.
          </li>
          <li>
            Support transparency, research integrity and responsible
            scholarly communication.
          </li>
        </ul>

        <h2>Editorial independence</h2>

        <p>
          Editorial decisions should be based on the academic quality,
          relevance and integrity of a manuscript. Financial
          considerations, including any applicable publication charges,
          must not influence acceptance or rejection decisions.
        </p>
      </section>
    </main>
  );
}
