import Link from "next/link";

export default function Page() {
  return (
    <div className="container page">
      <div className="eyebrow">AIMS & SCOPE</div>
      <h1>Aims and Scope</h1>
      <div className="prose"><p>Define the exact scientific scope, fields covered, interdisciplinary boundaries and article types here after editorial approval.</p></div>
    </div>
  );
}
