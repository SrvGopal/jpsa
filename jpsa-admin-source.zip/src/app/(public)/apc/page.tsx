import Link from "next/link";

export default function Page() {
  return (
    <div className="container page">
      <div className="eyebrow">ARTICLE PROCESSING CHARGES</div>
      <h1>APC & Waivers</h1>
      <div className="prose"><p>Publish the final APC, payment timing, waiver eligibility and refund policy here.</p><div className="notice">Do not advertise an APC until the policy is finalized.</div></div>
    </div>
  );
}
