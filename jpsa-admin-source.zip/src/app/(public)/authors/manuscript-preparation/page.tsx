import Link from "next/link";

export default function Page() {
  return (
    <div className="container page">
      <div className="eyebrow">MANUSCRIPT PREPARATION</div>
      <h1>Manuscript Preparation</h1>
      <div className="prose"><p>Publish the official formatting and preparation requirements after editorial approval.</p></div>
    </div>
  );
}
