import Link from "next/link";

export default function Page() {
  return (
    <div className="container page">
      <div className="eyebrow">PEER REVIEW</div>
      <h1>Peer Review</h1>
      <div className="prose"><p>Describe the actual review model used by JPSA, including screening, reviewer selection, review criteria, revisions and decisions.</p></div>
    </div>
  );
}
