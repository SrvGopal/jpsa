import Link from "next/link";

export default function Page() {
  return (
    <div className="container page">
      <div className="eyebrow">SUBMISSION PROCESS</div>
      <h1>Submission Process</h1>
      <div className="prose"><p>The online submission system will be introduced in Phase 2. This page can explain what authors should prepare before submission.</p><div className="notice">Submission system: Phase 2.</div></div>
    </div>
  );
}
