import Link from "next/link";

export default function Page() {
  return (
    <div className="container page">
      <div className="eyebrow">CORRECTIONS & RETRACTIONS</div>
      <h1>Corrections and Retractions</h1>
      <div className="prose"><p>Describe the process for corrections, expressions of concern and retractions.</p></div>
    </div>
  );
}
