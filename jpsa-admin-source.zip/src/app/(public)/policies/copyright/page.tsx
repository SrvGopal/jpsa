import Link from "next/link";

export default function Page() {
  return (
    <div className="container page">
      <div className="eyebrow">COPYRIGHT</div>
      <h1>Copyright & Licensing</h1>
      <div className="prose"><p>State the journal's actual copyright ownership and licensing terms.</p></div>
    </div>
  );
}
