import Link from "next/link";

export default function Page() {
  return (
    <div className="container page">
      <div className="eyebrow">AUTHORSHIP</div>
      <h1>Authorship Policy</h1>
      <div className="prose"><p>Define authorship criteria, contributor roles, changes to authorship and corresponding-author responsibilities.</p></div>
    </div>
  );
}
