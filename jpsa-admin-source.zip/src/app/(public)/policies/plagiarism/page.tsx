import Link from "next/link";

export default function Page() {
  return (
    <div className="container page">
      <div className="eyebrow">PLAGIARISM</div>
      <h1>Plagiarism Policy</h1>
      <div className="prose"><p>Define how JPSA handles plagiarism, duplicate publication and inappropriate text reuse.</p></div>
    </div>
  );
}
