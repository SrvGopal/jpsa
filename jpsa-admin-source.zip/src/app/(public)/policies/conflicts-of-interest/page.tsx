import Link from "next/link";

export default function Page() {
  return (
    <div className="container page">
      <div className="eyebrow">CONFLICTS OF INTEREST</div>
      <h1>Conflicts of Interest</h1>
      <div className="prose"><p>State how authors, reviewers and editors should disclose and manage conflicts.</p></div>
    </div>
  );
}
