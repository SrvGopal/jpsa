import Link from "next/link";

export default function Page() {
  return (
    <div className="container page">
      <div className="eyebrow">PUBLICATION ETHICS</div>
      <h1>Publication Ethics</h1>
      <div className="prose"><p>Publish the approved publication-ethics policy here.</p></div>
    </div>
  );
}
